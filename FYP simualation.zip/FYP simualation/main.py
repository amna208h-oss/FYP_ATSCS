import asyncio
import platform
import pygame
import random
import time
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from collections import defaultdict, deque

# ───────────── init & constants ─────────────
pygame.init()
WIDTH, HEIGHT = 900, 700
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Traffic Simulation – Independent Signal Controller with AI")
clock = pygame.time.Clock()
FONT = pygame.font.SysFont(None, 24)
FPS = 60

# Assets
VEHICLE_SIZE = (50, 40)
ASSETS = {
    "car": "assets/hatchback.png",
    "truck": "assets/box-truck.png",
    "bike": "assets/motorbike.png",
    "ambulance": "assets/ambulance.png",
}
IMAGES = {k: pygame.transform.scale(pygame.image.load(path).convert_alpha(), VEHICLE_SIZE) for k, path in ASSETS.items()}

# Colours
WHITE = (255, 255, 255)
GREY = (100, 100, 100)
DARK_GRASS = (100, 160, 60)
LIGHT_GRASS = (140, 200, 80)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
YELLOW = (255, 255, 0)
BLUE = (0, 0, 255)
ORANGE = (255, 165, 0)
BLACK = (0, 0, 0)
GRAY = (169, 169, 169)

# Geometry
INTER_LEFT, INTER_RIGHT = 373, 510
INTER_TOP, INTER_BOTTOM = 275, 385
LANE_CENTER = {"north": 470, "south": 410, "east": 365, "west": 305}
DIRECTIONS = ["north", "south", "east", "west"]

# Behaviour params
MIN_GAP = 60   # px between vehicles
SPAWN_INT = 1.2  # sec between spawns
AMB_FORCE = 60   # seconds max until forced ambulance
YELLOW_DURATION = 2.0  # seconds for yellow light phase
GREEN_DURATION = 10.0  # max seconds for green phase

# ───────────── background prerender ──────────
def make_bg():
    bg = pygame.Surface((WIDTH, HEIGHT))
    bg.fill(DARK_GRASS)
    rng = random.Random(1)
    for _ in range(2000):
        x, y = rng.randrange(WIDTH), rng.randrange(HEIGHT)
        ln = rng.randint(5, 15)
        dx = rng.choice([-1, 1]) * rng.random() * 2
        col = LIGHT_GRASS if rng.random() < 0.5 else DARK_GRASS
        pygame.draw.line(bg, col, (x, y), (x + dx, y - ln), 1)
    # roads
    pygame.draw.rect(bg, GREY, (390, 0, 120, HEIGHT))
    pygame.draw.rect(bg, GREY, (0, 290, WIDTH, 120))
    # dotted lanes
    cx = 450
    for y in range(0, INTER_TOP - 15, 30):
        pygame.draw.line(bg, WHITE, (cx, y), (cx, y + 15), 2)
    for y in range(INTER_BOTTOM + 40, HEIGHT, 30):
        pygame.draw.line(bg, WHITE, (cx, y), (cx, y + 15), 2)
    cy = 350
    for x in range(0, INTER_LEFT - 15, 30):
        pygame.draw.line(bg, WHITE, (x, cy), (x + 15, cy), 2)
    for x in range(INTER_RIGHT + 25, WIDTH, 30):
        pygame.draw.line(bg, WHITE, (x, cy), (x + 15, cy), 2)
    # stop lines
    pygame.draw.line(bg, WHITE, (390, 290), (510, 290), 5)
    pygame.draw.line(bg, WHITE, (390, 410), (510, 410), 5)
    pygame.draw.line(bg, WHITE, (510, 290), (510, 410), 5)
    pygame.draw.line(bg, WHITE, (390, 290), (390, 410), 5)
    return bg

BG = make_bg()

# ───────────── DQN Model ─────────────
class DQN(nn.Module):
    def __init__(self, state_size, action_size):
        super(DQN, self).__init__()
        self.fc1 = nn.Linear(state_size, 128)
        self.fc2 = nn.Linear(128, 128)
        self.fc3 = nn.Linear(128, action_size)
    
    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)

# ───────────── RL Agent ─────────────
class DQNAgent:
    def __init__(self, state_size, action_size):
        self.state_size = state_size
        self.action_size = action_size
        self.memory = deque(maxlen=2000)
        self.gamma = 0.95
        self.epsilon = 1.0
        self.epsilon_min = 0.01
        self.epsilon_decay = 0.995
        self.model = DQN(state_size, action_size)
        self.target_model = DQN(state_size, action_size)
        self.target_model.load_state_dict(self.model.state_dict())
        self.optimizer = optim.Adam(self.model.parameters(), lr=0.001)
        self.batch_size = 32
    
    def remember(self, state, action, reward, next_state, done):
        self.memory.append((state, action, reward, next_state, done))
    
    def act(self, state, amb_dir, queues, current_green, intersection_clear, yellow_timers, green_timer):
        # Rule-based policy: ambulance priority, then congestion-based
        if any(yellow_timers[d] > 0 for d in DIRECTIONS):  # No change during yellow
            return DIRECTIONS.index(current_green)
        if amb_dir is not None:
            return DIRECTIONS.index(amb_dir)
        if (green_timer >= GREEN_DURATION or queues[current_green] == 0) and intersection_clear:
            # Choose direction with most vehicles
            max_queue = max(queues.values())
            if max_queue == 0:
                return (DIRECTIONS.index(current_green) + 1) % 4  # Cycle to next direction
            candidates = [d for d in DIRECTIONS if queues[d] == max_queue]
            return DIRECTIONS.index(random.choice(candidates))
        return DIRECTIONS.index(current_green)
    
    def replay(self):
        if len(self.memory) < self.batch_size:
            return
        minibatch = random.sample(self.memory, self.batch_size)
        states, actions, rewards, next_states, dones = zip(*minibatch)
        states = torch.FloatTensor(states)
        actions = torch.LongTensor(actions)
        rewards = torch.FloatTensor(rewards)
        next_states = torch.FloatTensor(next_states)
        dones = torch.FloatTensor(dones)
        
        q_values = self.model(states).gather(1, actions.unsqueeze(1)).squeeze(1)
        next_q_values = self.target_model(next_states).max(1)[0]
        targets = rewards + (1 - dones) * self.gamma * next_q_values
        
        loss = nn.MSELoss()(q_values, targets)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay
    
    def update_target_model(self):
        self.target_model.load_state_dict(self.model.state_dict())

# ───────────── data holders ─────────────
vehicles = []
light_states = {d: "red" for d in DIRECTIONS}
current_green = "north"
light_states[current_green] = "green"
last_spawn = 0
last_amb = time.time()
throughput = 0
queues = defaultdict(int)
start = time.time()
episode = 0
total_reward = 0
agent = None
yellow_timers = {d: 0.0 for d in DIRECTIONS}
yellow_to_green = {d: False for d in DIRECTIONS}
pending_green = None
green_timer = 0.0

# ───────────── helpers ─────────────
rotate = lambda img, d: {
    "north": pygame.transform.rotate(img, -90),  # Face up
    "south": pygame.transform.rotate(img, 90),   # Face down
    "east": pygame.transform.rotate(img, 180),   # Face left (assuming base sprite faces right)
    "west": img                                  # Face right (no rotation)
}[d]

def spawn(force_amb=False):
    global vehicles, last_amb

    # Ensure no other ambulance exists
    ambulance_present = any(v["type"] == "ambulance" and v["state"] in ("approach", "in") for v in vehicles)
    if force_amb and not ambulance_present:
        v_type = "ambulance"
    elif not ambulance_present and random.random() < 0.005:
        v_type = "ambulance"
    else:
        v_type = random.choice(["car", "truck", "bike"])

    d = random.choice(DIRECTIONS)
    speed = 5 if v_type == "ambulance" else random.randint(2, 4)
    
    if d == "north":
        pos = [LANE_CENTER[d], -60]
    elif d == "south":
        pos = [LANE_CENTER[d], HEIGHT + 60]
    elif d == "east":
        pos = [WIDTH + 60, LANE_CENTER[d]]
    else:  # west
        pos = [-60, LANE_CENTER[d]]

    vehicles.append({
        "type": v_type,
        "sprite": rotate(IMAGES[v_type], d),
        "speed": speed,
        "start": d,
        "pos": pos,
        "state": "approach"
    })

    if v_type == "ambulance":
        last_amb = time.time()

def in_box(x, y):
    return INTER_LEFT <= x <= INTER_RIGHT and INTER_TOP <= y <= INTER_BOTTOM

def lane_gap_ok(v):
    global vehicles
    vx, vy = v["pos"]
    d = v["start"]
    for o in vehicles:
        if o is v or o["start"] != d:
            continue
        ox, oy = o["pos"]
        if d == "north" and 0 < oy - vy < MIN_GAP:
            return False
        if d == "south" and 0 < vy - oy < MIN_GAP:
            return False
        if d == "east" and 0 < vx - ox < MIN_GAP:
            return False
        if d == "west" and 0 < ox - vx < MIN_GAP:
            return False
    return True

def move(v):
    global light_states
    x, y = v["pos"]
    s = v["speed"]
    d = v["start"]
    if in_box(x, y):
        v["state"] = "in"
    if v["state"] == "approach" and light_states[d] != "green":  # Stop at yellow or red
        if d == "north" and y + VEHICLE_SIZE[1] >= INTER_TOP:
            return
        if d == "south" and y - VEHICLE_SIZE[1] <= INTER_BOTTOM:
            return
        if d == "east" and x - VEHICLE_SIZE[0] <= INTER_RIGHT:
            return
        if d == "west" and x + VEHICLE_SIZE[0] >= INTER_LEFT:
            return
    if not lane_gap_ok(v):
        return
    if d == "north":
        y += s
    elif d == "south":
        y -= s
    elif d == "east":
        x -= s  # Move left
    else:  # west
        x += s
    v["pos"] = [x, y]

def update_queues():
    global vehicles, queues
    queues.clear()
    for v in vehicles:
        if v["state"] == "approach":
            queues[v["start"]] += 1

def intersection_clear():
    global vehicles
    return not any(v["state"] == "in" for v in vehicles)

# ───────────── state and reward ─────────────
def get_state():
    global vehicles, light_states, current_green, queues, yellow_timers
    amb = {d: 0 for d in DIRECTIONS}
    for v in vehicles:
        if v["type"] == "ambulance" and v["state"] == "approach":
            amb[v["start"]] = 1
    green = {d: 1 if light_states[d] == "green" else 0 for d in DIRECTIONS}
    yellow = {d: 1 if yellow_timers[d] > 0 else 0 for d in DIRECTIONS}
    return np.array([
        queues["north"], queues["south"], queues["east"], queues["west"],
        amb["north"], amb["south"], amb["east"], amb["west"],
        green["north"], green["south"], green["east"], green["west"],
        yellow["north"], yellow["south"], yellow["east"], yellow["west"]
    ])

def get_reward(prev_throughput, prev_vehicles):
    global vehicles, throughput, queues, light_states
    reward = 0
    reward += 10 * (throughput - prev_throughput)
    for v in vehicles:
        if v["type"] == "ambulance" and v["state"] == "done" and v not in prev_vehicles:
            reward += 100
    reward -= sum(queues.values())
    for v in vehicles:
        if v["type"] == "ambulance" and v["state"] == "approach":
            reward -= 50
    if not intersection_clear() and sum(1 for d in light_states if light_states[d] == "green") > 1:
        reward -= 200
    return reward

# ───────────── initialize simulation ─────────────
def init_simulation():
    global vehicles, light_states, current_green, last_spawn, last_amb, throughput
    global episode, total_reward, agent, yellow_timers, yellow_to_green, pending_green, green_timer
    vehicles = []
    light_states = {d: "red" for d in DIRECTIONS}
    current_green = "north"
    light_states[current_green] = "green"
    last_spawn = time.time()
    last_amb = time.time()
    throughput = 0
    episode = 0
    total_reward = 0
    yellow_timers = {d: 0.0 for d in DIRECTIONS}
    yellow_to_green = {d: False for d in DIRECTIONS}
    pending_green = None
    green_timer = 0.0
    agent = DQNAgent(state_size=16, action_size=4)

# ───────────── update loop ─────────────
def update_loop():
    global vehicles, light_states, current_green, last_spawn, last_amb, throughput
    global episode, total_reward, agent, yellow_timers, yellow_to_green, pending_green, green_timer
    if agent is None:
        init_simulation()
    
    now = time.time()
    prev_vehicles = vehicles.copy()
    prev_throughput = throughput
    
    # Update yellow timers
    for d in DIRECTIONS:
        if yellow_timers[d] > 0:
            yellow_timers[d] -= 1.0 / FPS
            if yellow_timers[d] <= 0:
                light_states[d] = "green" if yellow_to_green[d] else "red"
                if yellow_to_green[d] and d == pending_green:
                    for k in DIRECTIONS:
                        if k != d:
                            light_states[k] = "red"
                    current_green = d
                    green_timer = 0.0
                    pending_green = None
                yellow_to_green[d] = False
                yellow_timers[d] = 0.0
    
    # Update green timer
    if light_states[current_green] == "green":
        green_timer += 1.0 / FPS
    
    # Spawn vehicles
    if now - last_spawn > SPAWN_INT:
        spawn(force_amb=now - last_amb > AMB_FORCE)
        if vehicles[-1]["type"] == "ambulance":
            last_amb = now
        last_spawn = now
    
    # Update queues
    update_queues()
    
    # Check for ambulance
    amb_dir = None
    for v in vehicles:
        if v["type"] == "ambulance" and v["state"] == "approach" and light_states[v["start"]] != "green":
            amb_dir = v["start"]
            break
    
    # Get state
    state = get_state()
    
    # Choose action using rule-based policy
    action = agent.act(state, amb_dir, queues, current_green, intersection_clear(), yellow_timers, green_timer)
    next_green = DIRECTIONS[action]
    
    # Handle signal transition with yellow phase
    if next_green != current_green and intersection_clear() and all(yellow_timers[d] == 0 for d in DIRECTIONS):
        pending_green = next_green
        if light_states[current_green] == "green":
            # Green to red: set current direction to yellow
            light_states[current_green] = "yellow"
            yellow_timers[current_green] = YELLOW_DURATION
            yellow_to_green[current_green] = False
        else:
            # Red to green: set next direction to yellow
            for k in DIRECTIONS:
                if k != next_green:
                    light_states[k] = "red"
            light_states[next_green] = "yellow"
            yellow_timers[next_green] = YELLOW_DURATION
            yellow_to_green[next_green] = True
    
    # Ensure a green direction if none exists and no yellow timers are active
    if all(light_states[d] == "red" for d in DIRECTIONS) and all(yellow_timers[d] == 0 for d in DIRECTIONS) and intersection_clear():
        max_queue = max(queues.values())
        if max_queue == 0:
            next_green = DIRECTIONS[(DIRECTIONS.index(current_green) + 1) % 4]
        else:
            candidates = [d for d in DIRECTIONS if queues[d] == max_queue]
            next_green = random.choice(candidates)
        pending_green = next_green
        light_states[next_green] = "yellow"
        yellow_timers[next_green] = YELLOW_DURATION
        yellow_to_green[next_green] = True
    
    # Move vehicles
    for v in vehicles:
        move(v)
    
    # Update vehicles and throughput
    for v in list(vehicles):
        x, y = v["pos"]
        if v["state"] == "in" and not in_box(x, y):
            v["state"] = "done"
            throughput += 1
    vehicles = [v for v in vehicles if -80 < v["pos"][0] < WIDTH + 80 and -80 < v["pos"][1] < HEIGHT + 80]
    
    # Calculate reward
    reward = get_reward(prev_throughput, prev_vehicles)
    total_reward += reward
    
    # Get next state
    next_state = get_state()
    
    # Store experience and train
    agent.remember(state, action, reward, next_state, False)
    agent.replay()
    if episode % 10 == 0:
        agent.update_target_model()
    
    # Render
    screen.blit(BG, (0, 0))
    # Draw lights
    posL = {"north": (530, 210), "south": (355, 415), "east": (530, 415), "west": (355, 210)}
    for d, (x, y) in posL.items():
        st = light_states[d]
        pygame.draw.rect(screen, BLACK, (x, y, 20, 75))
        pygame.draw.circle(screen, RED if st == "red" else GRAY, (x + 10, y + 12), 7)
        pygame.draw.circle(screen, YELLOW if st == "yellow" else GRAY, (x + 10, y + 37), 7)
        pygame.draw.circle(screen, GREEN if st == "green" else GRAY, (x + 10, y + 62), 7)
    # Draw vehicles
    for v in vehicles:
        screen.blit(v["sprite"], v["pos"])
    # Queue counters
    posCnt = {"north": (520, 140), "south": (370, 590), "east": (670, 260), "west": (180, 250)}
    for d, (x, y) in posCnt.items():
        screen.blit(FONT.render(str(queues[d]), True, BLACK), (x, y))
    elapsed = int(now - start)
    screen.blit(FONT.render(f"T: {elapsed}s  Out: {throughput}  Reward: {total_reward:.1f}", True, BLACK), (600, 20))
    
    pygame.display.flip()
    
    episode += 1

# ───────────── main loop ─────────────
async def async_main():
    init_simulation()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
        await update_loop()
        await asyncio.sleep(1.0 / FPS)

if platform.system() == "Emscripten":
    asyncio.ensure_future(async_main())
else:
    if __name__ == "__main__":
        init_simulation()
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
            update_loop()
            clock.tick(FPS)
        pygame.quit()